package com.example.projectinfo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Button;
import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView infoView = new TextView(this);
        infoView.setPadding(20, 20, 20, 20);

        StringBuilder info = new StringBuilder();
        info.append("Treble: ").append(isTrebleEnabled() ? "SIM" : "NÃO").append("\n");
        info.append("Partições Dinâmicas: ").append(hasDynamicPartitions() ? "SIM" : "NÃO").append("\n");
        info.append("Arquitetura: ").append(getArch());

        Button gsiButton = new Button(this);
        gsiButton.setText("Abrir site do PHH");
        gsiButton.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://github.com/phhusson/treble_experimentations/wiki"));
            startActivity(i);
        });

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.addView(infoView);
        layout.addView(gsiButton);

        infoView.setText(info.toString());
        setContentView(layout);
    }

    private boolean isTrebleEnabled() {
        File f = new File("/system/partition.prop");
        return f.exists();
    }

    private boolean hasDynamicPartitions() {
        return new File("/system/system_ext").exists() && new File("/dev/block/by-name").exists();
    }

    private String getArch() {
        String arch = System.getProperty("os.arch");
        if (arch.contains("arm64")) return "ARM64";
        else if (arch.contains("armeabi")) return "ARM32";
        else if (arch.contains("x86")) return "x86";
        else return arch;
    }
}