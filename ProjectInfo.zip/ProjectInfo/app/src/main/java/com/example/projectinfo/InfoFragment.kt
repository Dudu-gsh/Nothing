
package com.example.projectinfo

import android.os.Bundle
import android.os.SystemProperties
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class InfoFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_info, container, false)

        val treble = SystemProperties.get("ro.treble.enabled", "false")
        val dynamic = SystemProperties.get("ro.dynamic.partitions", "false")
        val abi = System.getProperty("os.arch") ?: "Desconhecido"

        val arch = when {
            abi.contains("arm64") -> "ARM64"
            abi.contains("arm") -> "ARM32"
            abi.contains("x86") -> "x86"
            else -> "Desconhecida"
        }

        view.findViewById<TextView>(R.id.trebleStatus).text = "Project Treble: $treble"
        view.findViewById<TextView>(R.id.dynamicStatus).text = "Partições Dinâmicas: $dynamic"
        view.findViewById<TextView>(R.id.architecture).text = "Arquitetura: $arch"

        return view
    }
}
